#ifndef __OCU__
#define __OCU__


void InitFreeTimer16_0(void);
void InitOCU_01(WORD ocp1, WORD ocp2) ;


#endif
