/*****************************************************************************/
/** \file rlt.h
 *****************************************************************************/

#ifndef _RLT_H
#define _RLT_H

void InitReloadTimer0(void);
__interrupt void ReloadTimer0(void);

#endif 