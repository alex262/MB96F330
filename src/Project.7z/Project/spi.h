#ifndef __SPI__
#define __SPI__

void InitSPI_1(void);
void InitSPI_2(void);

#endif
